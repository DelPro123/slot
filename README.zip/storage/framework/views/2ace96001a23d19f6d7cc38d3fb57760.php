<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>React in Laravel</title>
    <?php echo app('Illuminate\Foundation\Vite')->reactRefresh(); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/js/app.jsx']); ?>
</head>
<body>
    <div id="app"></div>
</body>
</html>
<?php /**PATH C:\Users\Administrator\slot-game\resources\views/app.blade.php ENDPATH**/ ?>