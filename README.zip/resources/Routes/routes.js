import Games from './Pages/Games';

// Add this to your existing routes
const routes = [
    // ... other routes
    { path: '/games', element: <Games /> },
];
